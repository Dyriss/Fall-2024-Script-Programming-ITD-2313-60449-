def main():
  # Get purchase price from user
  purchase_price = float(input("Enter the purchase price: $"))

  # Calculate down payment and remaining balance
  down_payment = purchase_price * 0.1
  remaining_balance = purchase_price - down_payment

  # Set monthly payment and interest rate
  monthly_payment = purchase_price * 0.05
  annual_interest_rate = 0.12

  # Print table header
  print("\nMonth\tBalance\tInterest\tPrincipal\tPayment\tRemaining Balance")
  print("-----\t-------\t-------\t-------\t-------\t-----------------")

  # Loop for each month until balance is paid off
  month = 1
  while remaining_balance > 0:
    # Calculate monthly interest
    monthly_interest = remaining_balance * annual_interest_rate / 12

    # Calculate principal paid (payment - interest)
    principal_paid = monthly_payment - monthly_interest

    # Update remaining balance
    remaining_balance -= principal_paid

    # Print month details with two decimal places
    print(f"{month}\t${remaining_balance:.2f}\t${monthly_interest:.2f}\t${principal_paid:.2f}\t${monthly_payment:.2f}\t${remaining_balance:.2f}")

    month += 1

if __name__ == "__main__":
  main()
