import math

def main():
  print("Think of a number between 1 and 100!")

  # Get lower and upper bounds from user
  lower_bound = int(input("Enter the lower bound (inclusive): "))
  upper_bound = int(input("Enter the upper bound (inclusive): "))

  # Validate input (bounds must be positive and lower < upper)
  if lower_bound <= 0 or upper_bound <= 0 or lower_bound >= upper_bound:
    print("Invalid input! Bounds must be positive integers with lower bound less than upper bound.")
    return

  # Calculate minimum number of guesses (using log2)
  min_guesses = math.ceil(math.log2(upper_bound - lower_bound + 1))

  # Guessing loop
  guess_count = 0
  while guess_count < min_guesses:
    guess_count += 1

    # Calculate the middle point for the guess
    guess = (lower_bound + upper_bound) // 2

    # Get user hint (improved to prevent cheating)
    hint = input(f"Is your number higher (h), lower (l), or equal (e) to {guess}?: ").lower()

    if hint not in ("h", "l", "e"):
      print("Invalid hint! Please enter 'h', 'l', or 'e'.")
      continue  # Skip this iteration and ask for a valid hint

    # Update bounds based on hint
    if hint == "h":
      lower_bound = guess + 1
    elif hint == "l":
      upper_bound = guess - 1
    else:
      break  # User entered 'e', number is found

  # Print result based on guess count
  if guess_count == min_guesses:
    print(f"Hooray! I've guessed your number in {guess_count} tries (minimum possible)!")
  else:
    print(f"I guessed your number in {guess_count} tries.")

if __name__ == "__main__":
  main()
