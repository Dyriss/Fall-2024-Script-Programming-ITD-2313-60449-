def main():
  # Get user input for starting salary, increase percentage, and number of years
  starting_salary = float(input("Enter the starting salary: $"))
  percentage_increase = float(input("Enter the annual percentage increase: "))
  number_of_years = int(input("Enter the number of years in the schedule: "))

  # Print table header
  print("\nYear\tSalary")
  print("----\t------")

  # Calculate and display salary for each year
  for year in range(1, number_of_years + 1):
    # Calculate salary with annual increase
    salary = starting_salary * (1 + (percentage_increase / 100)) ** (year - 1)
    # Print year and salary with two decimal places
    print(f"{year}\t${salary:.2f}")

if __name__ == "__main__":
  main()
