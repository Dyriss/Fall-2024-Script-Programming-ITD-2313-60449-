from images import Image

def sepia(image):
    """Converts the argument image to sepia."""
    for y in range(image.getHeight()):
        for x in range(image.getWidth()):
            (r, g, b) = image.getPixel(x, y)

            
            r = int(r * 0.393 + g * 0.769 + b * 0.189)
            g = int(r * 0.349 + g * 0.686 + b * 0.168)
            b = int(r * 0.272 + g * 0.534 + b * 0.131)

            
            r = min(max(r, 0), 255)
            g = min(max(g, 0), 255)
            b = min(max(b, 0), 255)

            image.setPixel(x, y, (r, g, b))

def main(filename = "smokey.gif"):
    image = Image(filename)
    print("Close the image window to continue. ")
    image.draw()  

    sepia(image)
    print("Close the image window to quit. ")
    image.draw()

if __name__ == "__main__":
    main()  
