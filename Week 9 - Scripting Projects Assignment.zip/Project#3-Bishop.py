import turtle
import math

def drawFractalLine(turtle, length, angle, level):
    if level == 0:
        turtle.forward(length)
    else:
        drawFractalLine(turtle, length / 3, angle, level - 1)
        turtle.left(60)
        drawFractalLine(turtle, length / 3, angle, level - 1)
        turtle.right(120)
        drawFractalLine(turtle, length / 3, angle, level - 1)
        turtle.left(60)
        drawFractalLine(turtle, length / 3, angle, level - 1)

def drawKochSnowflake(turtle, size, level):
    turtle.penup()
    turtle.goto(-size / 2, size / 2 * math.sqrt(3) / 3)
    turtle.pendown()

    for i in range(3):
        drawFractalLine(turtle, size, 0, level)
        turtle.right(120)

# Set up the turtle graphics window
turtle.setup(width=800, height=600)
window = turtle.Screen()
window.bgcolor("white")

# Create a turtle object
bob = turtle.Turtle()
bob.speed(0)  # Set the drawing speed to the fastest

# Draw the Koch snowflake
drawKochSnowflake(bob, 200, 3)  # Adjust the size and level as desired

# Keep the window open until it's closed manually
window.exitonclick()
