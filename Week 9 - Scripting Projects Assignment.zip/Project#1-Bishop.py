import turtle
import math

def drawCircle(turtle, x, y, radius):
    turtle.penup()
    turtle.goto(x, y - radius)
    turtle.pendown()
    circumference = 2.0 * math.pi * radius
    distance = circumference / 120.0

    for _ in range(120):
        turtle.forward(distance)
        turtle.left(3)

def main():
    turtle.setup(width=800, height=600)
    window = turtle.Screen()
    bob = turtle.Turtle()
    x = 50
    y = 75
    radius = 100

    drawCircle(bob, x, y, radius)

    window.exitonclick()

main()
