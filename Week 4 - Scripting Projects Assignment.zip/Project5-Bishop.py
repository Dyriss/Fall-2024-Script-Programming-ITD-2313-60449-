def predict_population(initial_population, growth_rate, growth_period, total_time):


  # Check for valid growth rate
  if growth_rate <= 0:
    raise ValueError("Growth rate must be greater than 0.")

  # Calculate the growth factor per growth period
  growth_factor = 1 + growth_rate

  # Calculate the number of growth periods
  num_periods = int(total_time / growth_period)

  # Calculate the final population
  final_population = initial_population * (growth_factor ** num_periods)

  return final_population

def main():
 
  try:
    initial_organisms = int(input("Enter the initial number of organisms: "))
    growth_rate = float(input("Enter the growth rate (greater than 0): "))
    growth_time = float(input("Enter the number of hours to achieve growth rate: "))
    total_hours = float(input("Enter the total number of hours for growth: "))

    predicted_population = predict_population(initial_organisms, growth_rate, growth_time, total_hours)
    print("Predicted population after", total_hours, "hours:", predicted_population)
  except ValueError as e:
    print("Error:", e)

if __name__ == "__main__":
  main()
