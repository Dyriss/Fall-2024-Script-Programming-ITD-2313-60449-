def is_equilateral(side1, side2, side3):
  """
  This function checks if the three sides form an equilateral triangle.

  Args:
      side1 (float): Length of the first side of the triangle.
      side2 (float): Length of the second side of the triangle.
      side3 (float): Length of the third side of the triangle.

  Returns:   

      bool: True if the triangle is equilateral, False otherwise.
  """  

  # Check if all sides are equal
  return side1 == side2 and side2 == side3

def main():

  side1 = float(input("Enter the length of side 1: "))
  side2 = float(input("Enter the length of side 2: "))
  side3 = float(input("Enter the length of side 3: "))

  if is_equilateral(side1, side2, side3):
    print("The triangle is equilateral.")
  else:
    print("The triangle is not equilateral.")

if __name__ == "__main__":
  main()
