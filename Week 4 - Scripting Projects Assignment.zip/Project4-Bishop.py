def calculate_bouncing_distance(initial_height, bounces, bounciness_index=0.6):
 

  total_distance = initial_height
  for _ in range(bounces):
    total_distance += 2 * initial_height * bounciness_index
    initial_height *= bounciness_index

  return total_distance

def main():

  initial_height = float(input("Enter the initial height (in feet): "))
  bounces = int(input("Enter the number of bounces: "))

  total_distance = calculate_bouncing_distance(initial_height, bounces)
  print("Total distance traveled: {:.2f} feet".format(total_distance))

if __name__ == "__main__":
  main()
