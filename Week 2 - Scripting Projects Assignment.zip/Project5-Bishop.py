Mass = float(input("Mass : "))
Velocity =float(input("Velocity : "))
print("")

Momentum = Mass * Velocity

print("The object's momentum is " + str(Momentum))
