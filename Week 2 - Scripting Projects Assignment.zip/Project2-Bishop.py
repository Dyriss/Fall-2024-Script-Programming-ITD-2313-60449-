edge = float(input("Edge Length: "))

area = 6 * edge**2

print("Surface Area: "+str(area))
