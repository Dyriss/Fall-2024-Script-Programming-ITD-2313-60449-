name = "Christian Bishop"  
address = "1801 E 4th St"
phone_number = "9189770554"
print(f"Name: {name}")
print(f"Address: {address}")
print(f"Phone Number: {phone_number}")
