b = int(input("Input the base : "))
h = int(input("Input the height : "))

area = b * h / 2

print("area = ", area)
