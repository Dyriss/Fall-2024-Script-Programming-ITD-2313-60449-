width = float(input("Enter the width: "))
height = float(input("Enter the height: "))

area = width * height
print("The area is", area, "square units.")
