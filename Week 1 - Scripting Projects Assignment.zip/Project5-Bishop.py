def calculate_volume(height, width, depth):
   return height * width * depth

height = float(input('Enter the height of the cuboid: '))
width = float(input('Enter the width of the cuboid: '))
depth = float(input('Enter the depth of the cuboid: '))

volume = calculate_volume(height, width, depth)

print(f'The volume of the cuboid is {volume} cubic units.')
