def main():
  """Prompts user for a filename, reads the lines, and allows navigation."""
  filename = input("Enter the filename: ")
  try:
    with open(filename, 'r') as file:
      lines = file.readlines()
  except FileNotFoundError:
    print(f"Error: File '{filename}' not found.")
    return

  num_lines = len(lines)

  while True:
    print(f"\nThe file has {num_lines} lines.")
    line_number = int(input("Enter a line number [0 to quit]: "))
    if line_number == 0:
      break

    if 0 < line_number <= num_lines:
      print(f"Line {line_number}: {lines[line_number - 1].strip()}")  # Adjust for 0-based indexing
    else:
      print(f"Error: Invalid line number. Please enter a number between 1 and {num_lines}.")

if __name__ == "__main__":
  main()
