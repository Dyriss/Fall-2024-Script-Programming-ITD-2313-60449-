def inputFloat(prompt):
  
  while True:
    try:
      value = float(input(prompt))
      # Check for single decimal point (optional)
      if str(value).count('.') > 1:
        raise ValueError("Invalid input. Only one decimal point allowed.")
      return value
    except ValueError:
      print("Invalid input. Please enter a number with digits and optional single decimal point.")

