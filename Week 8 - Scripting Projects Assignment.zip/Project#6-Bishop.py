def myRange(stop, start=None, step=1):
 
  # Handle default values for start and step
  if start is None:
    start = 0
  if step == 0:
    raise ValueError("Step cannot be zero")

  # Determine increment direction based on step
  direction = 1 if step > 0 else -1

  # Build the list based on start, stop, and step
  result = []
  current = start
  while direction * (current < stop) > 0:
    result.append(current)
    current += step
  return result

# Test cases
print(myRange(5))  # Output: [0, 1, 2, 3, 4]
print(myRange(10, 2))  # Output: [2, 3, 4, 5, 6, 7, 8, 9]
print(myRange(10, 2, 3))  # Output: [2, 5, 8]
print(myRange(-5, 0, -2))  # Output: [-4, -2] (negative step)
# Try with step 0 (raises ValueError)
# print(myRange(5, step=0))
