def years_to_minutes(years):
   
  days = years * 365
  minutes_per_day = 24 * 60  
  total_minutes = days * minutes_per_day

  return total_minutes

def main():
  

  years = float(input("Enter the number of years: "))
  total_minutes = years_to_minutes(years)

  print(f"{years} years is equal to approximately {total_minutes:.2f} minutes.")

if __name__ == "__main__":
  main()
