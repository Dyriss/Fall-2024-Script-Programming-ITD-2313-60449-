def calculate_weekly_pay(hourly_wage, regular_hours, overtime_hours):
   
  regular_pay = hourly_wage * regular_hours

  overtime_pay = overtime_hours * (hourly_wage * 1.5)

  total_pay = regular_pay + overtime_pay

  return total_pay

def main():

  try:
    hourly_wage = float(input("Enter the hourly wage: "))
    regular_hours = float(input("Enter the total regular hours: "))
    overtime_hours = float(input("Enter the total overtime   hours:"))

    if hourly_wage <= 0 or regular_hours < 0 or overtime_hours < 0:
      raise ValueError("Input values must be positive.")

    total_pay = calculate_weekly_pay(hourly_wage, regular_hours, overtime_hours)
    print(f"The employee's total weekly pay is: ${total_pay:.2f}")

  except ValueError as e:
    print("Error: Invalid input. Please enter positive values for wage and hours.")

if __name__ == "__main__":
  main()
