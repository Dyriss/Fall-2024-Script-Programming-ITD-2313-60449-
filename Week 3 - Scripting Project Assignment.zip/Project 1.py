def calculate_tax(income):
  
  tax_rate = 0.2  
  tax = income * tax_rate
  return tax

def main():
  income = float(input("Enter your income: "))
  tax = calculate_tax(income)

  
  rounded_tax = round(tax, 2)
  formatted_tax = "{:.2f}".format(rounded_tax)  

  print(f"Your calculated tax is: ${formatted_tax}")

if __name__ == "__main__":
  main()
